package com.bv.coupon.shared.beans.rules;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

/**
 * 优惠券计算规则
 * @author 姚半仙
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class CalculationRule {

    /** 折扣 */
    private Discount discount;

    // 每个人领券数量
    private Integer limitation;

    private Long deadline;

    private String ddlDateTime;

}
