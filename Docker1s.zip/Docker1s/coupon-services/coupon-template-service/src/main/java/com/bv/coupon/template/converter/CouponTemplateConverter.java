package com.bv.coupon.template.converter;

import com.bv.coupon.shared.beans.TemplateInfo;
import com.bv.coupon.template.entity.CouponTemplate;

public class CouponTemplateConverter {

    public static TemplateInfo convertToTemplateInfo(CouponTemplate template) {

        return TemplateInfo.builder()
                .id(template.getId())
                .name(template.getName())
                .description(template.getDescription())
                .type(template.getCategory().getCode())
                .shopId(template.getShopId())
                .available(template.getAvailable())
                .rule(template.getRule())
                .build();
    }
}
