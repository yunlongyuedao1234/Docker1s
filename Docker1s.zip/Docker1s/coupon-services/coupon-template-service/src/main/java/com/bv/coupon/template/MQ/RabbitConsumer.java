package com.bv.coupon.template.MQ;

import lombok.extern.slf4j.Slf4j;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.stereotype.Component;

@Component
@Slf4j
public class RabbitConsumer {

    @RabbitListener(queues="${bv.rabbitmq.queue}")
    public void recievedMessage(String msg){
        log.debug("Recieved Message: {}", msg);
        System.out.println("Recieved Message: Place Order using ConponID " + msg);
    }
}
