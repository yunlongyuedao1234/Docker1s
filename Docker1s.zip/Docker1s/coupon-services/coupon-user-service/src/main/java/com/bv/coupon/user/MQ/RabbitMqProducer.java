package com.bv.coupon.user.MQ;

import lombok.extern.slf4j.Slf4j;
import org.springframework.amqp.core.AmqpTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
@Slf4j
public class RabbitMqProducer {
    @Autowired
    private AmqpTemplate amqpTemplate;

    @Value("${bv.rabbitmq.exchange}")
    private String exchange;

    @Value("${bv.rabbitmq.routingkey}")
    private String routingKey;

    public void produceMsg(String msg){
        amqpTemplate.convertAndSend(exchange, routingKey, msg);
        log.debug("Send msg = {}", msg);
        System.out.println("Send Message: Place Order using ConponID " + msg);
    }
}
