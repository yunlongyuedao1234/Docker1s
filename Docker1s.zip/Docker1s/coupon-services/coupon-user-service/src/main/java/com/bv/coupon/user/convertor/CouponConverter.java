package com.bv.coupon.user.convertor;

import com.bv.coupon.user.entity.Coupon;
import com.bv.coupon.shared.beans.CouponInfo;

/**
 * @author WIN_21
 */
public class CouponConverter {

    public static CouponInfo convertToCoupon(Coupon coupon) {

        return CouponInfo.builder()
                .id(coupon.getId())
                .templateId(coupon.getTemplateId())
                .status(coupon.getStatus().getCode())
                .userId(coupon.getUserId())
                .shopId(coupon.getShopId())
                .template(coupon.getTemplateInfo())
                .build();
    }
}
