package com.bv.coupon.calculation.processor;

import com.bv.coupon.shared.beans.PlaceOrder;

/**
 * @author WIN_21
 */
public interface RuleProcessor {
    // 计算优惠券
    PlaceOrder calculate(PlaceOrder settlement);
}
