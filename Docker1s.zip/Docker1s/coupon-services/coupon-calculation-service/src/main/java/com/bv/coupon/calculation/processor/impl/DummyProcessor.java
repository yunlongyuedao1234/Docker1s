package com.bv.coupon.calculation.processor.impl;

import com.bv.coupon.calculation.processor.AbstractRuleProcessor;
import com.bv.coupon.calculation.processor.RuleProcessor;
import com.bv.coupon.shared.beans.PlaceOrder;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

/**
 * 空实现
 * @author WIN_21
 */
@Slf4j
@Component
public class DummyProcessor extends AbstractRuleProcessor implements RuleProcessor {

    @Override
    public PlaceOrder calculate(PlaceOrder order) {
        double totalAmount = goodsCostSum(order.getProducts());
        order.setCost(totalAmount);
        return order;
    }
}
